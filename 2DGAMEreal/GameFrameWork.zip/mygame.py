from pico2d import *
import game_framework
import start_state

pico2d.open_canvas(800,500)
game_framework.run(start_state)
pico2d.close_canvas()

